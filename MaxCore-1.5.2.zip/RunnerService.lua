-- lib/RunService.lua — Pure Lua 5.1+ RunnerService with Enhanced Disconnect Support

local DEFAULTS = {
    safe = true,
    priority = 78,
    maxCatchUp = 3,
    _maxFails = 3,
    tickRate = 60,
    maxDt = 0.5,
}

local function clampDt(dt, maxDt)
    if dt ~= dt or dt <= 0 then return 1 / 60 end
    return (dt > maxDt) and maxDt or dt
end

local function sortByPriority(a, b)
    return (a.priority == b.priority)
        and (a.id < b.id)
        or (a.priority < b.priority)
end

local RunnerService = {}
RunnerService.__index = RunnerService

function RunnerService.new(opts)
    opts           = opts or {}
    local self     = setmetatable({}, RunnerService)

    self._log      = (opts.logger and opts.logger.log)
        and function(...) opts.logger:log(...) end
        or function(...) print("[Runner]", ...) end

    self._time     = opts.timeFn or os.clock
    self._sleep    = opts.sleepFn
    self._tickRate = opts.tickRate or DEFAULTS.tickRate
    self._maxDt    = opts.maxDt or DEFAULTS.maxDt

    self._jobs     = { Heartbeat = {}, Stepped = {}, RenderStepped = {} }
    self._dirty    = { Heartbeat = false, Stepped = false, RenderStepped = false }

    self._started  = false
    self._thread   = nil
    self._running  = false
    self._lastTime = nil

    -- Signal proxy for channel-style access
    local function makeSignal(channel)
        return {
            Connect = function(_, fn, opts)
                return self:bind(channel, fn, opts or {})
            end
        }
    end

    -- Expose signal proxies for each default channel
    self.Heartbeat     = makeSignal("Heartbeat")
    self.Stepped       = makeSignal("Stepped")
    self.RenderStepped = makeSignal("RenderStepped")

    return self
end

function RunnerService:_resort(channel)
    table.sort(self._jobs[channel], sortByPriority)
    self._dirty[channel] = false
end

local function callJob(self, job, dt)
    if job.paused then return end

    if job.safe ~= false then
        local ok, err = pcall(job.fn, dt)
        if not ok then
            job._failCount = (job._failCount or 0) + 1
            self._log(string.format("RunnerService [%s] error: %s", job.id, tostring(err)))
            if job._failCount >= (job._maxFails or DEFAULTS._maxFails) then
                self._log(string.format("RunnerService [%s] disabled after repeated errors", job.id))
                job.paused = true
            end
        else
            job._failCount = 0
        end
    else
        job.fn(dt)
    end
end

function RunnerService:_tickJob(job, dt)
    dt = clampDt(dt, self._maxDt)

    if job.interval and job.interval > 0 then
        job._lastAcc = (job._lastAcc or 0) + dt
        if job._lastAcc < job.interval then return end

        local runs = math.floor(job._lastAcc / job.interval)
        local maxRuns = job.maxCatchUp or DEFAULTS.maxCatchUp
        runs = math.min(runs, maxRuns)
        local step = job.interval

        job._lastAcc = job._lastAcc - runs * step
        for _ = 1, runs do
            callJob(self, job, step)
            if job.once then
                job.paused = true; break
            end
        end
    else
        callJob(self, job, dt)
    end
end

function RunnerService:step(dt)
    local now = self._time()
    if not dt then
        if not self._lastTime then
            dt = 1 / self._tickRate
            self._lastTime = now
        else
            dt = now - self._lastTime
            self._lastTime = now
        end
    end
    dt = clampDt(dt, self._maxDt)

    for _, channel in ipairs({ "Stepped", "Heartbeat", "RenderStepped" }) do
        if self._dirty[channel] then self:_resort(channel) end
        for _, job in ipairs(self._jobs[channel]) do
            self:_tickJob(job, dt)
        end
    end
end

function RunnerService:start()
  if self._started then return end
  self._started, self._running, self._lastTime = true, true, nil

  local frame = 1 / self._tickRate
  self._log("RunnerService started (infinite loop @ " .. tostring(self._tickRate) .. "Hz)")

  self._thread = coroutine.create(function()
    while self._running do
      local before = self._time()
      self:step()
      local after = self._time()
      local elapsed = after - before
      local delay = frame - elapsed

      if self._sleep then
        self._sleep(math.max(delay, 0))
      else
        -- No sleepFn: yield minimally to avoid locking up
        coroutine.yield()
      end
    end
  end)

  -- Resume the coroutine repeatedly to keep it alive
  coroutine.wrap(function()
    while self._running do
      local ok, err = coroutine.resume(self._thread)
      if not ok then
        self._log("RunnerService loop error: " .. tostring(err))
        break
      end
    end
  end)()
end

function RunnerService:stop()
    if not self._started then return end
    self._running = false
    self._started = false
    self._thread = nil
    self._log("RunnerService stopped")
end

-- Enhanced bind function that returns a connection object
function RunnerService:bind(channel, fn, opts)
    opts = opts or {}; channel = channel or "Heartbeat"

    self._jobs[channel] = self._jobs[channel] or {}
    self._dirty[channel] = true

    local id = opts.id or ("%s-%d-%d"):format(channel, math.floor(self._time() * 1e6), math.random(1000, 9999))
    local job = {
        id = id,
        signal = channel,
        fn = fn,
        tag = opts.tag,
        priority = opts.priority or DEFAULTS.priority,
        interval = opts.interval,
        maxCatchUp = opts.maxCatchUp or DEFAULTS.maxCatchUp,
        once = opts.once,
        safe = (opts.safe == nil) and DEFAULTS.safe or opts.safe,
        paused = false,
        _lastAcc = 0,
        _failCount = 0,
        _maxFails = opts.maxFails or DEFAULTS._maxFails,
    }

    table.insert(self._jobs[channel], job)
    if opts.autoStart ~= false then self:start() end
    
    -- Return connection object with disconnect capability
    local connection = {
        id = id,
        channel = channel,
        Connected = true,
        
        -- Disconnect method
        Disconnect = function(self_conn)
            if not self_conn.Connected then return end
            
            -- Remove the job from the channel
            local jobList = self._jobs[channel]
            for i = #jobList, 1, -1 do
                if jobList[i].id == id then
                    table.remove(jobList, i)
                    self._dirty[channel] = true
                    break
                end
            end
            
            self_conn.Connected = false
            self._log("Disconnected job: " .. id .. " from " .. channel)
        end,
        
        -- Pause method
        Pause = function(self_conn)
            if not self_conn.Connected then return end
            for _, jobList in pairs(self._jobs) do
                for _, job in ipairs(jobList) do
                    if job.id == id then
                        job.paused = true
                        return
                    end
                end
            end
        end,
        
        -- Resume method
        Resume = function(self_conn)
            if not self_conn.Connected then return end
            for _, jobList in pairs(self._jobs) do
                for _, job in ipairs(jobList) do
                    if job.id == id then
                        job.paused = false
                        return
                    end
                end
            end
        end
    }
    
    return connection
end

function RunnerService:Connect(channelOrFn, maybeFnOrOpts, maybeOpts)
    local channel, fn, opts

    if type(channelOrFn) == "function" then
        channel, fn, opts = "Heartbeat", channelOrFn, maybeFnOrOpts or {}
    else
        channel, fn, opts = channelOrFn, maybeFnOrOpts, maybeOpts or {}
    end

    return self:bind(channel, fn, opts)
end

-- Legacy unbind method (still works for backward compatibility)
--- @deprecated This function is no longer recommended. Use '#:Disconnect()' instead.
function RunnerService:unbind(idOrTag)
    for channel, list in pairs(self._jobs) do
        for i = #list, 1, -1 do
            local job = list[i]
            if job.id == idOrTag or job.tag == idOrTag then
                table.remove(list, i)
                self._log("Unbound job: " .. (job.id or "unknown") .. " from " .. channel)
            end
        end
        self._dirty[channel] = true
    end
end

function RunnerService:pause(idOrTag)
    for _, list in pairs(self._jobs) do
        for _, job in ipairs(list) do
            if job.id == idOrTag or job.tag == idOrTag then job.paused = true end
        end
    end
end

function RunnerService:resume(idOrTag)
    for _, list in pairs(self._jobs) do
        for _, job in ipairs(list) do
            if job.id == idOrTag or job.tag == idOrTag then job.paused = false end
        end
    end
end

function RunnerService:every(seconds, fn, opts)
    opts = opts or {}; opts.interval = seconds
    return self:bind("Heartbeat", function(_) fn() end, opts)
end

function RunnerService:defer(fn, opts)
    opts = opts or {}
    return self:bind("Heartbeat", function() fn() end, {
        once = true,
        priority = opts.priority or DEFAULTS.priority,
        tag = opts.tag
    })
end

-- NEW method to disconnect all connections
function RunnerService:disconnectAll()
    for channel in pairs(self._jobs) do
        self._jobs[channel] = {}
        self._dirty[channel] = true
    end
    self._log("Disconnected all jobs from all channels")
end

-- NEW method to get connection info
function RunnerService:getConnectionInfo()
    local info = {}
    for channel, jobList in pairs(self._jobs) do
        info[channel] = #jobList
    end
    return info
end

function RunnerService:destroy()
    self:stop()
    self:disconnectAll()
    for k in pairs(self._jobs) do self._jobs[k] = {} end
end

return RunnerService
