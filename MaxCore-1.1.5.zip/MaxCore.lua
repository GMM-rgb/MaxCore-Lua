--!strict Lua
--[[
    ./lib/MaxCore.lua
    Framework - A Lua-based core module addon for task management, event handling and more.

    Author: Maximus F. | Github: @GMM-rgb
    Date: 2025-07-31
    Version: 1.0.0

    Copyright (c) 2025 GMM-rgb
    Licensed under the MIT License.
--]]

local debugMode = false -- debug mode flag

-- Get the current line number for debugging purposes
local function getLine()
    local info = debug.getinfo(2, "l")
    return info and info.currentline or -1
end

-- Get the file name the function is exectuted within
local function getFileName()
    -- File information
    local info = debug.getinfo(1, "S")
    local fileInfo = info.source
    -- Return the file information
    return fileInfo or nil
end

-- Lenum is property definition for color codes and font types. etc.
-- WIP - still needs more properties, as well as implimenting it into the coreModule.
local lenum = {
    Font = {
        DEFAULT = "default",
        MONOSPACE = "monospace",
        SANS_SERIF = "sans-serif",
        SERIF = "serif",
        ARIAL = "arial"
    },
    Color = {
        RED = "31",       -- red
        CYAN = "36",      -- cyan
        YELLOW = "33",    -- yellow
        MAGENTA = "35",   -- magenta
        GREEN = "32",     -- green
        WHITE_ON_RED = "41;37", -- white on red
        WHITE = "37"      -- white
    },
    PropertyApplyType = {
        Highlight = {
           WHITE = "37;" .. ...,
           RED = "41;" .. ...,
        }
    }
}

-- This module provides color printing functionality.
-- It allows printing text in different colors to the console.
---@alias LogLevel
---| "ERROR"
---| "INFO"
---| "WARNING"
---| "DEBUG"
---| "SUCCESS"
---| "CRITICAL"

---Prints the message in ANSI color based on log level keyword.
---@param level LogLevel
---@param message string
local function colorPrint(level, message)
    local colorKeywords = {
        ERROR = "31",       -- red
        INFO = "36",        -- cyan
        WARNING = "33",     -- yellow
        DEBUG = "35",       -- magenta
        SUCCESS = "32",     -- green
        CRITICAL = "41;37", -- white on red
        DEFAULT = "41",
    }

    local code = colorKeywords[level] or "37" -- default to white
    print("\27[" .. code .. "m" .. message .. "\27[0m")
end

-- This module provides a simple task management system with wait functionality.
local function sleep(timeWait)
    local t = os.clock()
    while os.clock() - t <= timeWait do end
end

local MainKit = {}
MainKit.__index = MainKit

-- WaitUtilitys module
function MainKit.new()
    local selfModule = setmetatable({}, MainKit)
    return selfModule
end

-- Task module
local task = MainKit.new()
task.__index = task

-- Thread spawning (core)
function task.seed(fn, ...)
    local coro = coroutine.create(fn)
    local s, err = coroutine.resume(coro, ...)

    if not s then
        colorPrint("ERROR", "Task Error: " .. err)
    end

    local oldCoro = coro

    local success = task:WaitForCondition(function()
        return oldCoro ~= nil
    end, 1)

    if coroutine.status(coro) == "dead" then
        if debugMode then
            colorPrint("DEBUG", "Thread task completed. - " .. string.upper("maxcore.lua") .. " - " .. tostring(getLine()))
            colorPrint("DEBUG", "Task result: " .. tostring(coro))
        end

        local trySuccess, errorClose = pcall(function()
            if success then
                colorPrint("INFO", "Closed old coroutine runtime thread.")
            end
        end)

        if errorClose then
            colorPrint("CRITICAL", "Closing failed on coroutine thread." .. errorClose)
        elseif trySuccess then
            colorPrint("SUCCESS", "Success on pcall coroutine thread.")
        end
    else
        colorPrint("INFO", "Thread task is still running.")
    end
end

-- ONE UNIVERSAL DESTROY FUNCTION - handles everything
function MainKit.__index:Destroy(identifier, scope)
    -- -- If called as x:Destroy() (self is the variable)
    -- if type(self) ~= "table" or (self ~= MainKit and not getmetatable(self)) then
    --     -- This means someone called variable:Destroy() directly
    --     error("Direct :Destroy() not supported. Use core.MainKit.Destroy(variable, value) or core.MainKit:Destroy('varName')")
    -- end
    
    -- Handle different call patterns
    if identifier == nil then
        return error("Destroy function requires an identifier.")
    end
    
    -- Pattern 1: MainKit.Destroy(varName, value) - creates destroyable variable
    if type(identifier) == "string" and scope ~= nil then
        local varName = identifier
        local value = scope
        local targetScope = _G
        
        print("Creating destroyable variable: " .. varName)
        
        -- Create the destroyable wrapper
        local destroyable
        if type(value) == "table" then
            destroyable = value
        else
            destroyable = {_value = value}
        end
        
        -- Add Destroy method
        destroyable.Destroy = function()
            print("Destroying variable: " .. varName)
            task.seed(function()
                if targetScope[varName] ~= nil then
                    local oldValue = targetScope[varName]
                    targetScope[varName] = nil
                    colorPrint("SUCCESS", "Variable destroyed: " .. varName)
                    collectgarbage()
                else
                    colorPrint("WARNING", "Variable not found: " .. varName)
                end
            end)
        end
        
        -- Set up metamethods AFTER adding Destroy method
        if type(value) ~= "table" then
            setmetatable(destroyable, {
                __tostring = function() return tostring(value) end,
                __call = function(_, ...) 
                    if type(value) == "function" then return value(...) end
                end,
                __add = function(_, other) return value + other end,
                __sub = function(_, other) return value - other end,
                __mul = function(_, other) return value * other end,
                __div = function(_, other) return value / other end,
                __eq = function(_, other) return value == other end,
                __lt = function(_, other) return value < other end,
                __le = function(_, other) return value <= other end,
                __index = function(t, k)
                    if k == "Destroy" then return rawget(t, k) end
                    if k == "_value" then return rawget(t, k) end
                    if type(value) == "table" then return value[k] end
                    return nil
                end
            })
        end
        
        -- Set in global scope and return
        targetScope[varName] = destroyable
        return destroyable
    end
    
    -- Pattern 2: MainKit:Destroy("varName") - traditional destroy
    local varName = tostring(identifier)
    print("Destroying identifier: " .. varName)

    task.seed(function()
        local destroyed = false
        local oldValue = nil

        -- Try to destroy from global scope
        if _G[varName] ~= nil then
            oldValue = _G[varName]
            _G[varName] = nil
            destroyed = true
            colorPrint("SUCCESS", "Global variable destroyed: " .. varName .. " (was: " .. tostring(oldValue) .. ")")

        -- Try to destroy from a specific table/scope if provided
        elseif scope and type(scope) == "table" and scope[varName] ~= nil then
            oldValue = scope[varName]
            scope[varName] = nil
            destroyed = true
            colorPrint("SUCCESS", "Table entry destroyed: " .. varName .. " (was: " .. tostring(oldValue) .. ")")
        else
            colorPrint("WARNING", "Variable not found in accessible scopes: " .. varName)
        end

        if destroyed then
            collectgarbage()
            colorPrint("SUCCESS", "Object Variable destroyed successfully. (name: " .. tostring(varName) .. ")" .. " (value: " .. tostring(oldValue) .. ")" .. " - " .. string.upper("maxcore.lua") .. " - " .. tostring(getLine()))
        end
    end)

    colorPrint("DEBUG", "Attempting to destroy: " .. varName)
end

--#region Destroy Function Examples
-- Examples of how to use the Destroy function
-- This section is for documentation purposes and should not be executed.
-- You can use the Destroy function in two ways:
--[[
    documentation needs to be updated, but here is the basic idea:

    -- WAY 1: Create destroyable variable that supports x:Destroy()
    local x = core.MainKit.Destroy("x", 1)           -- Creates x = 1 with :Destroy()
    local name = core.MainKit.Destroy("name", "hi")  -- Creates name = "hi" with :Destroy()
    local data = core.MainKit.Destroy("data", {a=1}) -- Creates data = {a=1} with :Destroy()

    -- Now these work:
    print(x)     -- prints 1
    print(name)  -- prints "hi" 
    print(data.a) -- prints 1

    x:Destroy()    -- WORKS!
    name:Destroy() -- WORKS!
    data:Destroy() -- WORKS!

    -- WAY 2: Traditional destroy (still works)
    someVar = "hello"
    core.MainKit:Destroy("someVar")  -- Destroys existing variable

    -- EXAMPLES:

    -- Numbers
    local myNum = core.MainKit.Destroy("myNum", 42)
    print(myNum + 8)  -- prints 50 (math works)
    myNum:Destroy()   -- destroys it

    -- Strings  
    local myStr = core.MainKit.Destroy("myStr", "hello world")
    print(myStr)      -- prints "hello world"
    myStr:Destroy()   -- destroys it

    -- Tables
    local myTable = core.MainKit.Destroy("myTable", {users = {}, config = {debug = true}})
    print(myTable.config.debug)  -- prints true
    myTable:Destroy()            -- destroys it

    -- Functions
    local myFunc = core.MainKit.Destroy("myFunc", function(x) return x * 2 end)
    print(myFunc(5))  -- prints 10
    myFunc:Destroy()  -- destroys it
]]
--#endregion

-- Universal proxy to allow :Wait() on any value or objects
function MainKit.WithWait(value)
    local proxy = {}
    function proxy:Wait(n)
        return task:Wait(n)
    end
    setmetatable(proxy, {
        __index = function(_, k)
            return value[k]
        end,
        __call = function(_, ...)
            if type(value) == "function" then
                return value(...)
            end
        end
    })
    -- Allow direct access to the value
    return proxy
end

-- Wait function (core)
function MainKit:Wait(n)
    if not n then
        n = 0
    end
    task.seed(function()
        sleep(n)
        return true
    end)
end

-- Wait for a condition to be true with a timeout
function MainKit:WaitForCondition(condition, timeout)
    local startTime = os.clock()
    while not condition() do
        if os.clock() - startTime > timeout then
            return false
        end
        task:Wait(0.1) -- Yield to allow other tasks to run
    end
    -- Condition met
    colorPrint("SUCCESS", "Condition met within timeout.")
    return true
end

local Event = {}
Event.__index = Event

local InjectedEvents = {}
function Event.__Name()
    return "Event Object"
end

function Event.new()
    table.insert(InjectedEvents, Event.__Name)
    if debugMode then
        colorPrint("DEBUG", "Created Event: " .. Event.__Name())
    end

    return setmetatable({
        _listeners = {},
        _nextId = 1,
    }, Event)
end

function Event:Connect(fn, ...)
    local id = self._nextId
    self._nextId = self._nextId + 1
    self._listeners[id] = fn
    return {
        Disconnect = function()
            self._listeners[id] = nil
        end
    }
end

function Event:Once(fn)
    local connection
    connection = self:Connect(function(...)
        fn(...)
        connection.Disconnect()
    end)
end

function Event:Fire(...)
    for _, listener in pairs(self._listeners) do
        listener(...)
    end
end

function task.wait(n)
    if not n then
        n = 0
    end

    task.seed(function()
        sleep(n)
        return true
    end)
end

if debugMode then
    colorPrint("DEBUG", "Testing Event Transfer...")
end
local eventTestSuccess = false

local test = Event.new()
local connection = test:Connect(function(...)
    if debugMode then
        colorPrint("DEBUG", "Value: " .. tostring(...))
    end

    eventTestSuccess = true
end)

test:Fire("Hello World" .. " - MaxCore.lua - " .. getLine())
connection:Disconnect()

if eventTestSuccess then
    colorPrint("SUCCESS", "Event Testing was successful.")
else
    colorPrint("ERROR", "Event system test failed.")
end

task.seed(function()
   colorPrint("SUCCESS", string.upper("core system online - core.lua - " .. tostring(getLine())))
end)

colorPrint("WARNING", "----------------------------------")

return {
    __call = function(_, env)
        return {
            -- Include all functions directly
            MainKit = MainKit,
            lenum = lenum,
            sleep = sleep,
            colorPrint = colorPrint,
            WithWait = MainKit.WithWait,
            traceback = getLine,
            newEvent = Event.new,
            Event = Event,
            Fire = Event.Fire,
            Once = Event.Once,
            Connect = Event.Connect,
            Disconnect = Event.Disconnect,
            WaitForCondition = MainKit.WaitForCondition,
            task = task,
            wait = task.wait,
            spawn = task.seed,
            Destroy = MainKit.Destroy,
            getFileName = getFileName,
        }
    end
}
